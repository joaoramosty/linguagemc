#include <stdio.h>

int main() {
    char string[100]; 
    printf("Digite uma string: ");
    scanf("%s", string); 

    printf("A string digitada é: %s\n", string); 
    return 0;
}
